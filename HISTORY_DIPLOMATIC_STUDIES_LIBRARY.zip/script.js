const searchInput = document.getElementById("searchInput");
const clearSearch = document.getElementById("clearSearch");
const resourceCards = [...document.querySelectorAll(".resource")];
const resultCount = document.getElementById("resultCount");

function filterResources() {
  const q = searchInput.value.trim().toLowerCase();
  let count = 0;
  resourceCards.forEach(card => {
    const haystack = (card.innerText + " " + card.dataset.search).toLowerCase();
    const visible = haystack.includes(q);
    card.classList.toggle("hidden", !visible);
    if (visible) count++;
  });
  resultCount.textContent = `${count} collection${count === 1 ? "" : "s"}`;
}
searchInput.addEventListener("input", filterResources);
clearSearch.addEventListener("click", () => {
  searchInput.value = "";
  filterResources();
  searchInput.focus();
});
filterResources();

// Light/dark theme
document.getElementById("themeBtn").addEventListener("click", () => {
  document.body.classList.toggle("light");
  document.getElementById("themeBtn").textContent =
    document.body.classList.contains("light") ? "☾" : "☀";
});

// Search book catalogues. The app opens legitimate catalogue/search pages;
// it does not download copyrighted books or bypass access restrictions.
document.getElementById("bookSearchBtn").addEventListener("click", searchBooks);
document.getElementById("bookQuery").addEventListener("keydown", e => {
  if (e.key === "Enter") searchBooks();
});
function searchBooks() {
  const query = document.getElementById("bookQuery").value.trim();
  const box = document.getElementById("bookLinks");
  if (!query) {
    box.textContent = "Enter a book title, author or subject first.";
    return;
  }
  const q = encodeURIComponent(query);
  const links = [
    ["Internet Archive", `https://archive.org/search?query=${q}`],
    ["Google Books", `https://books.google.com/books?q=${q}`],
    ["Project Gutenberg", `https://www.gutenberg.org/ebooks/search/?query=${q}`],
    ["Open Access Books (DOAB)", `https://www.doabooks.org/en/search?query=${q}`],
    ["Google Scholar", `https://scholar.google.com/scholar?q=${q}`]
  ];
  box.innerHTML = links.map(([label, url]) =>
    `<a href="${url}" target="_blank" rel="noopener">${label} — search “${escapeHTML(query)}” ↗</a>`
  ).join("");
}
function escapeHTML(value) {
  return value.replace(/[&<>"']/g, ch => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
  }[ch]));
}

// Notes stored locally in this browser/device. Keep sensitive information out.
const NOTES_KEY = "historyDiplomaticLibraryNotes";
let notes = [];
try { notes = JSON.parse(localStorage.getItem(NOTES_KEY) || "[]"); } catch (_) { notes = []; }
const noteTitle = document.getElementById("noteTitle");
const noteText = document.getElementById("noteText");
const noteStatus = document.getElementById("noteStatus");
function saveNotesToStorage() {
  try {
    localStorage.setItem(NOTES_KEY, JSON.stringify(notes));
    noteStatus.textContent = "Saved on this device.";
  } catch (_) {
    noteStatus.textContent = "Could not save. Check browser storage settings.";
  }
}
function renderNotes() {
  const holder = document.getElementById("savedNotes");
  holder.innerHTML = "";
  notes.forEach((note, index) => {
    const item = document.createElement("div");
    item.className = "saved-note";
    const title = document.createElement("strong");
    title.textContent = note.title || "Untitled note";
    const body = document.createElement("div");
    body.textContent = note.text;
    const remove = document.createElement("button");
    remove.textContent = "Delete note";
    remove.addEventListener("click", () => {
      notes.splice(index, 1);
      saveNotesToStorage();
      renderNotes();
    });
    item.append(title, body, remove);
    holder.appendChild(item);
  });
}
document.getElementById("saveNoteBtn").addEventListener("click", () => {
  const text = noteText.value.trim();
  if (!text) {
    noteStatus.textContent = "Write a note before saving.";
    return;
  }
  notes.unshift({ title: noteTitle.value.trim(), text, created: Date.now() });
  saveNotesToStorage();
  renderNotes();
  noteTitle.value = "";
  noteText.value = "";
});
document.getElementById("clearNoteBtn").addEventListener("click", () => {
  noteTitle.value = "";
  noteText.value = "";
  noteStatus.textContent = "";
});
renderNotes();

// Timeline events
const TIMELINE_KEY = "historyDiplomaticTimeline";
let events = [];
try { events = JSON.parse(localStorage.getItem(TIMELINE_KEY) || "[]"); } catch (_) { events = []; }
function renderTimeline() {
  const holder = document.getElementById("timeline");
  holder.innerHTML = "";
  events.sort((a, b) => a.date.localeCompare(b.date)).forEach(event => {
    const item = document.createElement("div");
    item.className = "timeline-item";
    const strong = document.createElement("strong");
    strong.textContent = `${event.date} — ${event.name}`;
    const detail = document.createElement("div");
    detail.textContent = event.detail;
    item.append(strong, detail);
    holder.appendChild(item);
  });
}
document.getElementById("addEventBtn").addEventListener("click", () => {
  const date = document.getElementById("eventDate").value.trim();
  const name = document.getElementById("eventName").value.trim();
  const detail = document.getElementById("eventDetail").value.trim();
  if (!date || !name) {
    alert("Please enter at least the date/year and event name.");
    return;
  }
  events.push({ date, name, detail });
  try { localStorage.setItem(TIMELINE_KEY, JSON.stringify(events)); } catch (_) {}
  document.getElementById("eventDate").value = "";
  document.getElementById("eventName").value = "";
  document.getElementById("eventDetail").value = "";
  renderTimeline();
});
renderTimeline();
